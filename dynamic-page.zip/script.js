function changeText() {
  const textElement = document.getElementById('dynamic-text');
  textElement.textContent = 'The text has been changed dynamically!';
}

function changeStyle() {
  const styledElement = document.getElementById('styled-text');
  styledElement.style.color = 'blue';
  styledElement.style.fontWeight = 'bold';
  styledElement.style.backgroundColor = '#f0f0f0';
}

function toggleElement() {
  const container = document.getElementById('container');
  const existingBox = document.getElementById('box');

  if (existingBox) {
    container.removeChild(existingBox);
  } else {
    const newBox = document.createElement('div');
    newBox.id = 'box';
    newBox.textContent = 'I was added dynamically!';
    newBox.style.padding = '10px';
    newBox.style.marginTop = '10px';
    newBox.style.border = '2px solid #333';
    container.appendChild(newBox);
  }
}
